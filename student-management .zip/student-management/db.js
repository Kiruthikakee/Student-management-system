// Step 3: Database connectivity (SQLite file: students.db)
// Uses the SQLite built into Node.js (v22.5+), so no extra install or compiler is needed.
const { DatabaseSync } = require('node:sqlite');
const path = require('path');

const db = new DatabaseSync(process.env.DB_FILE || path.join(__dirname, 'students.db'));

db.exec(`
  CREATE TABLE IF NOT EXISTS students (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    email      TEXT NOT NULL UNIQUE,
    phone      TEXT,
    course     TEXT NOT NULL,
    year       INTEGER NOT NULL CHECK (year BETWEEN 1 AND 6),
    dob        TEXT,
    address    TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  )
`);

module.exports = db;
