// Step 5: Automated API test (run with: npm test). Uses a throwaway database.
process.env.DB_FILE = ':memory:';
const assert = require('assert');
const app = require('./server');

const server = app.listen(0, async () => {
  const base = `http://localhost:${server.address().port}/api/students`;
  const call = async (url, method = 'GET', body) => {
    const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: body && JSON.stringify(body) });
    return { status: r.status, data: r.status === 204 ? null : await r.json() };
  };
  const sample = { name: 'Asha Raman', email: 'asha@example.com', phone: '9876543210', course: 'Computer Science', year: 2 };
  try {
    let r = await call(base, 'POST', sample);
    assert.equal(r.status, 201); const id = r.data.id;
    console.log('PASS  create student');

    r = await call(base, 'POST', sample);
    assert.equal(r.status, 409); console.log('PASS  duplicate email rejected');

    r = await call(base, 'POST', { name: '', email: 'bad', course: '', year: 9 });
    assert.equal(r.status, 400); assert.ok(r.data.errors.length >= 3); console.log('PASS  validation errors');

    r = await call(base); assert.equal(r.data.length, 1); console.log('PASS  list students');
    r = await call(`${base}?search=asha`); assert.equal(r.data.length, 1);
    r = await call(`${base}?search=zzz`); assert.equal(r.data.length, 0); console.log('PASS  search');

    r = await call(`${base}/${id}`); assert.equal(r.data.name, 'Asha Raman'); console.log('PASS  view one student');

    r = await call(`${base}/${id}`, 'PUT', { ...sample, course: 'Data Science', year: 3 });
    assert.equal(r.data.course, 'Data Science'); assert.equal(r.data.year, 3); console.log('PASS  update student');

    r = await call(`${base}/${id}`, 'DELETE'); assert.equal(r.status, 204);
    r = await call(`${base}/${id}`); assert.equal(r.status, 404); console.log('PASS  delete student');

    console.log('\nAll tests passed.');
  } catch (e) { console.error('FAIL ', e.message); process.exitCode = 1; }
  server.close();
});
