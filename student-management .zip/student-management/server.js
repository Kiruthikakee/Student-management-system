// Step 2 + 4: REST API with CRUD operations
const express = require('express');
const path = require('path');
const db = require('./db');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---------- validation ----------
function validate(body) {
  const errors = [];
  const s = {
    name: String(body.name ?? '').trim(),
    email: String(body.email ?? '').trim().toLowerCase(),
    phone: String(body.phone ?? '').trim(),
    course: String(body.course ?? '').trim(),
    year: Number(body.year),
    dob: String(body.dob ?? '').trim(),
    address: String(body.address ?? '').trim(),
  };
  if (!s.name) errors.push('Name is required.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s.email)) errors.push('Enter a valid email address.');
  if (s.phone && !/^[0-9+\-\s()]{7,20}$/.test(s.phone)) errors.push('Enter a valid phone number.');
  if (!s.course) errors.push('Course is required.');
  if (!Number.isInteger(s.year) || s.year < 1 || s.year > 6) errors.push('Year must be between 1 and 6.');
  return { s, errors };
}

// ---------- routes ----------
// READ all (with optional ?search=)
app.get('/api/students', (req, res) => {
  const q = String(req.query.search || '').trim();
  const rows = q
    ? db.prepare(`SELECT * FROM students
                  WHERE name LIKE @q OR email LIKE @q OR course LIKE @q
                  ORDER BY name COLLATE NOCASE`).all({ q: `%${q}%` })
    : db.prepare('SELECT * FROM students ORDER BY name COLLATE NOCASE').all();
  res.json(rows);
});

// READ one
app.get('/api/students/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM students WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ errors: ['Student not found.'] });
  res.json(row);
});

// CREATE
app.post('/api/students', (req, res) => {
  const { s, errors } = validate(req.body);
  if (errors.length) return res.status(400).json({ errors });
  try {
    const info = db.prepare(`INSERT INTO students (name, email, phone, course, year, dob, address)
                             VALUES (@name, @email, @phone, @course, @year, @dob, @address)`).run(s);
    res.status(201).json(db.prepare('SELECT * FROM students WHERE id = ?').get(info.lastInsertRowid));
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return res.status(409).json({ errors: ['A student with this email already exists.'] });
    res.status(500).json({ errors: ['Server error.'] });
  }
});

// UPDATE
app.put('/api/students/:id', (req, res) => {
  const { s, errors } = validate(req.body);
  if (errors.length) return res.status(400).json({ errors });
  try {
    const info = db.prepare(`UPDATE students SET name=@name, email=@email, phone=@phone, course=@course,
                             year=@year, dob=@dob, address=@address WHERE id=@id`).run({ ...s, id: req.params.id });
    if (!info.changes) return res.status(404).json({ errors: ['Student not found.'] });
    res.json(db.prepare('SELECT * FROM students WHERE id = ?').get(req.params.id));
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return res.status(409).json({ errors: ['A student with this email already exists.'] });
    res.status(500).json({ errors: ['Server error.'] });
  }
});

// DELETE
app.delete('/api/students/:id', (req, res) => {
  const info = db.prepare('DELETE FROM students WHERE id = ?').run(req.params.id);
  if (!info.changes) return res.status(404).json({ errors: ['Student not found.'] });
  res.status(204).end();
});

const PORT = process.env.PORT || 3000;
if (require.main === module) {
  app.listen(PORT, () => console.log(`Student Management System running at http://localhost:${PORT}`));
}
module.exports = app;
