// Step 1: Frontend logic - talks to the REST API with fetch()
const $ = (id) => document.getElementById(id);
const API = '/api/students';
let students = [];
let pendingDeleteId = null;

const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => t.classList.remove('show'), 2200);
}

async function api(url, options) {
  const res = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...options });
  if (res.status === 204) return null;
  const data = await res.json();
  if (!res.ok) throw new Error((data.errors || ['Something went wrong.']).join('\n'));
  return data;
}

async function load() {
  const q = $('search').value.trim();
  try {
    students = await api(q ? `${API}?search=${encodeURIComponent(q)}` : API);
  } catch (e) {
    toast('Could not load students. Is the server running?');
    students = [];
  }
  render();
}

function render() {
  $('count').textContent = students.length === 1 ? '1 student' : `${students.length} students`;
  $('empty').hidden = students.length > 0;
  $('rows').innerHTML = students.map((s) => `
    <tr>
      <td class="name">${esc(s.name)}</td>
      <td>${esc(s.course)}</td>
      <td>Year ${esc(s.year)}</td>
      <td>${esc(s.email)}</td>
      <td class="right">
        <button class="btn small" data-act="view" data-id="${s.id}">View</button>
        <button class="btn small" data-act="edit" data-id="${s.id}">Edit</button>
        <button class="btn small del" data-act="delete" data-id="${s.id}">Delete</button>
      </td>
    </tr>`).join('');
}

// ---- add / edit ----
function openForm(student) {
  $('formErrors').hidden = true;
  $('form').reset();
  $('formTitle').textContent = student ? 'Edit student' : 'Add student';
  $('id').value = student?.id ?? '';
  ['name', 'email', 'phone', 'dob', 'course', 'year', 'address'].forEach((f) => { $(f).value = student?.[f] ?? (f === 'year' ? 1 : ''); });
  $('formDialog').showModal();
  $('name').focus();
}

$('form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = $('id').value;
  const body = JSON.stringify(Object.fromEntries(
    ['name', 'email', 'phone', 'dob', 'course', 'year', 'address'].map((f) => [f, $(f).value])
  ));
  try {
    await api(id ? `${API}/${id}` : API, { method: id ? 'PUT' : 'POST', body });
    $('formDialog').close();
    toast(id ? 'Changes saved' : 'Student added');
    load();
  } catch (err) {
    $('formErrors').innerHTML = err.message.split('\n').map((m) => `<p>${esc(m)}</p>`).join('');
    $('formErrors').hidden = false;
  }
});

// ---- table actions ----
$('rows').addEventListener('click', async (e) => {
  const btn = e.target.closest('button');
  if (!btn) return;
  const id = btn.dataset.id;
  const s = students.find((x) => String(x.id) === id);
  if (btn.dataset.act === 'edit') openForm(s);
  if (btn.dataset.act === 'delete') {
    pendingDeleteId = id;
    $('deleteText').textContent = `${s.name} will be permanently removed. This can't be undone.`;
    $('deleteDialog').showModal();
  }
  if (btn.dataset.act === 'view') {
    const full = await api(`${API}/${id}`);
    $('viewBody').innerHTML = `
      <div class="detail">
        <h2>${esc(full.name)}</h2>
        <dl>
          <dt>Email</dt><dd>${esc(full.email)}</dd>
          <dt>Phone</dt><dd>${esc(full.phone) || '—'}</dd>
          <dt>Course</dt><dd>${esc(full.course)}, year ${esc(full.year)}</dd>
          <dt>Date of birth</dt><dd>${esc(full.dob) || '—'}</dd>
          <dt>Address</dt><dd>${esc(full.address) || '—'}</dd>
          <dt>Added on</dt><dd>${esc(full.created_at)}</dd>
        </dl>
      </div>`;
    $('viewDialog').showModal();
  }
});

$('confirmDelete').addEventListener('click', async () => {
  try {
    await api(`${API}/${pendingDeleteId}`, { method: 'DELETE' });
    toast('Student deleted');
  } catch (err) { toast(err.message); }
  $('deleteDialog').close();
  load();
});

$('addBtn').addEventListener('click', () => openForm());
$('cancelBtn').addEventListener('click', () => $('formDialog').close());
$('closeView').addEventListener('click', () => $('viewDialog').close());
$('cancelDelete').addEventListener('click', () => $('deleteDialog').close());

let t;
$('search').addEventListener('input', () => { clearTimeout(t); t = setTimeout(load, 200); });

load();
