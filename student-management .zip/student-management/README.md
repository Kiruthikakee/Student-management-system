# Student Management System

Full-stack app: **HTML/CSS/JS** frontend, **Node.js + Express** REST API, **SQLite** database.

## Run it
```
npm install
npm start        # http://localhost:3000
npm test         # automated API tests
```
Requires Node.js 22.13 or newer (uses the built-in SQLite module).

## Structure
```
server.js        REST API + CRUD routes
db.js            SQLite connection and table creation
test.js          API tests
public/          index.html, style.css, app.js (frontend)
```

## API
| Method | Endpoint            | Purpose                       |
|--------|---------------------|-------------------------------|
| GET    | /api/students       | List students (`?search=`)    |
| GET    | /api/students/:id   | View one student              |
| POST   | /api/students       | Add a student                 |
| PUT    | /api/students/:id   | Update a student              |
| DELETE | /api/students/:id   | Delete a student              |
